package t3a7;

import java.util.Scanner;

/**
 *
 * @author esmer
 */
public class T3A7 {

    public static void main(String[] args) {
       // secuenciales();
       // impares();
       // trabajadores();
       // alumnos();
    }

    public static void secuenciales() {
        Scanner obj = new Scanner(System.in);
        System.out.println("SUMA DE NUMEROS SECUENCIALES");
        System.out.println("Ingrese la cantidad de numeros que desa sumar ");
        int n = obj.nextInt();
        System.out.println("Ingrese el numero de inicio ");
        int i = obj.nextInt();
        int l = i + (n - 1), s = 0;
        for (i = i; i <= l; i++) {
            s = s + i;
            if (i == l) {
                System.out.println("La suma de sus " + n + " numeros consecutivos es " + s);
            }
        }
    }

    public static void impares() {
        Scanner obj = new Scanner(System.in);
        System.out.println("PRODUCTO DE NUMEROS IMPARES");
        int s = 1, k;
        for (int i = 1; i <= 10; i++) {
            System.out.print("Ingrese su numero impar " + i + ": ");
            int m = obj.nextInt();
            k = m % 2;
            if (k == 1) {
                s = s * m;
                if (i == 10) {
                    System.out.println("El producto de sus 10 numeros impares es: " + s);
                }
            } else {
                System.out.println("Su numero no es impar, intentelo de nuevo");
                i--;
            }
        }
    }

    public static void trabajadores() {
        Scanner obj = new Scanner(System.in);
        System.out.println("PROMEDIO DE SALARIOS DE TRABAJADORES");
        System.out.println("�Cuantos trabajadores registrar�?");
        int t = obj.nextInt();
        int p = 0;
        String d = "";
        for (int i = 1; i <= t; i++) {
            System.out.println("Ingrese el nombre del trabajador " + i);
            String n = obj.next();
            System.out.println("Ingrese el salario de " + n);
            int s = obj.nextInt();
            p = p + s;
            if (i < t - 1) {
                d = d + n + ", ";
            } else if (i == t - 1) {
                d = d + n + " y ";
            }

            if (i == t) {
                d = d + n;
                System.out.println("El promedio de los salarios de \n" + d + "\nes: " + p / t);
            }
        }
    }

    public static void alumnos() {
        Scanner obj = new Scanner(System.in);
        System.out.println("EDADES Y ESTATURAS DE ALUMNOS");
        int p = 0, r = 0;
        float u = 0, s = 0;
        for (int i = 1; i <= 5; i++) {
            System.out.println("Ingrese la edad del alumno " + i);
            int d = obj.nextInt();
            System.out.println("Ingrese la estatura del alumno " + i);
            float t = obj.nextFloat();
            if (d > 18) {
                p = p + 1;
            }
            if (t > 1.75) {
                r = r + 1;
            }
            s = s + d;
            u = u + t;
            if (i == 5) {
                System.out.println("La media de la edad es: " + s / 5 + "\nLa media de la estatura es: " + u / 5
                        + "\nHay " + p + " alumnos que  tienen mas de 18 a�os\nHay " + r + " alumnos que miden mas de 1.75");
            }

        }
    }
}
